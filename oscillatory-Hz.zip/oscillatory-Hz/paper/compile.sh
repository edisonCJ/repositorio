#!/bin/bash
# Compile the SciPost manuscript
set -e
echo "Compiling paper_oscillatory.tex..."
pdflatex -interaction=nonstopmode paper_oscillatory.tex
bibtex paper_oscillatory
pdflatex -interaction=nonstopmode paper_oscillatory.tex
pdflatex -interaction=nonstopmode paper_oscillatory.tex
echo "Done: paper_oscillatory.pdf"
