# Oscillatory H(z) as a Probe of Ultralight Axions

**Paper:** *Oscillatory H(z) as a Probe of Ultralight Axions: Joint Analysis of CC, Planck, DESI, and Pantheon+ with Microphysical Parameter Inversion*

**Author:** Edison Carrasco-Jiménez  
**Journal:** SciPost Physics Core 9, 024 (2026)  
**DOI:** [to be assigned]

---

## Repository structure

```
oscillatory-Hz/
├── paper/
│   ├── paper_oscillatory.tex     # LaTeX source
│   ├── references.bib            # Bibliography (35 entries, all with DOI)
│   ├── SciPost.cls               # SciPost document class
│   ├── SciPost_bibstyle.bst      # SciPost bibliography style
│   ├── header_logo.png           # Journal header logo
│   ├── fig1.png – fig7.png       # All figures
│   └── paper_oscillatory.pdf     # Compiled manuscript
│
├── code/
│   ├── final_analysis.py         # Main MCMC (emcee, CC-only, 5 parameters)
│   ├── final_synthetic.py        # Injection-recovery tests (6 cases)
│   ├── make_chi2_profile.py      # Profile likelihood chi2(epsilon)
│   ├── final_figures.py          # Generates Figures 1–5
│   └── make_joint_figures.py     # Generates Figures 6–7
│
├── data/
│   └── cc_data.npy               # 30-point cosmic chronometer compilation
│
├── chains/
│   ├── mcmc_flat_final.npy       # MCMC flat chains (14,912 x 5 samples)
│   ├── final_stats.npy           # Summary statistics (medians, CI, AIC, BIC)
│   ├── chi2_profile_final.npy    # Profile chi2(epsilon) over 61 points
│   └── synthetic_final.npy       # Injection-recovery results (6 cases)
│
├── README.md
├── requirements.txt
└── .gitignore
```

---

## Requirements

Python 3.9+ with:

```bash
pip install -r requirements.txt
```

Contents of `requirements.txt`:
```
numpy
scipy
emcee
matplotlib
```

---

## Reproduce the analysis

### Step 1 — Run the CC-only MCMC
```bash
python code/final_analysis.py
```
Produces: `chains/mcmc_flat_final.npy`, `chains/final_stats.npy`, `chains/chi2_profile_final.npy`

### Step 2 — Run injection-recovery tests
```bash
python code/final_synthetic.py
```
Produces: `chains/synthetic_final.npy`

### Step 3 — Generate all figures
```bash
python code/final_figures.py       # Figures 1–5
python code/make_joint_figures.py  # Figures 6–7
```
Figures are saved to `paper/fig1.png` ... `paper/fig7.png`

### Step 4 — Compile the paper
```bash
cd paper/
pdflatex paper_oscillatory.tex
bibtex paper_oscillatory
pdflatex paper_oscillatory.tex
pdflatex paper_oscillatory.tex
```

---

## Data

### Cosmic chronometers (`data/cc_data.npy`)

NumPy array of shape (30, 3): columns are `[z, H(z), sigma_H]`.

Sources:
| Reference | z range | N pts |
|-----------|---------|-------|
| Stern et al. (2010), doi:10.1088/1475-7516/2010/02/008 | 0.07–0.90 | 9 |
| Moresco et al. (2012), doi:10.1088/1475-7516/2012/08/006 | 0.18–1.04 | 8 |
| Moresco (2015), doi:10.1093/mnrasl/slv037 | 1.36 | 1 |
| Moresco et al. (2016), doi:10.1088/1475-7516/2016/05/014 | 0.38–0.48 | 5 |
| Zhang et al. (2014), doi:10.1088/1674-4527/14/10/002 | 0.12–0.28 | 4 |
| Borghi et al. (2022), doi:10.3847/2041-8213/ac3fb2 | 1.97 | 1 |

### External datasets (not redistributed — download from original sources)

- **Planck 2018:** https://pla.esac.esa.int
- **DESI DR1 BAO:** https://data.desi.lbl.gov/doc/releases/dr1/
- **Pantheon+ SNIa:** https://github.com/PantheonPlusSH0ES/DataRelease

---

## MCMC chains

### `chains/mcmc_flat_final.npy`
Shape: (14912, 5). Columns: `[H0, Omega_m, epsilon, omega, delta]`.

### `chains/final_stats.npy`
25-element array with: chi2_LCDM, AIC_LCDM, BIC_LCDM, H0_LCDM, Om_LCDM,
chi2_MAP, AIC_model, BIC_model, H0_MAP, Om_MAP, eps_MAP, omega_MAP, delta_MAP,
H0_med, Om_med, eps_med, omega_med, delta_med, eps_16, eps_84, omega_16, omega_84,
eps_95, eps_95_profile, dAIC, dBIC, dchi2, N, tau_int.

### `chains/chi2_profile_final.npy`
Shape: (2, 61). Row 0: epsilon grid. Row 1: delta_chi2(epsilon).

### `chains/synthetic_final.npy`
Shape: (6, 7). Columns: eps_inj, eps_rec, eps_lo, eps_hi, bias, dchi2, covered.

---

## Citation

If you use this code or data, please cite:

```bibtex
@article{CarrascoJimenez2026,
  author  = {Carrasco-Jim\'enez, Edison},
  title   = {Oscillatory $H(z)$ as a Probe of Ultralight Axions},
  journal = {SciPost Physics Core},
  volume  = {9},
  pages   = {024},
  year    = {2026},
  doi     = {10.21468/SciPostPhysCore.9.024}
}
```

---

## License

Code: MIT License.  
Data (cc_data.npy): compiled from published sources listed above; 
please cite original references when using.
