import numpy as np
import emcee
from scipy.optimize import minimize
from scipy.interpolate import interp1d
from scipy.optimize import brentq

# ── Data ──
data = np.load('/home/claude/cc_data.npy')
z_obs, H_obs, sigma = data[:,0], data[:,1], data[:,2]
N = len(z_obs)

def H_LCDM(z, H0, Om): return H0*np.sqrt(Om*(1+z)**3+(1-Om))
def H_model(z, H0, Om, eps, omega, delta):
    return H_LCDM(z,H0,Om)*(1+eps*np.sin(omega*z+delta))

# ── ΛCDM marginalized best-fit ──
def neg_lkl_lcdm(p):
    H0,Om=p
    if not(60<H0<80 and 0.20<Om<0.45): return 1e9
    return 0.5*np.sum(((H_obs-H_LCDM(z_obs,H0,Om))/sigma)**2)
r0=minimize(neg_lkl_lcdm,[70,0.30],method='Nelder-Mead')
chi2_lcdm=r0.fun; H0_lcdm,Om_lcdm=r0.x
print(f"LCDM: H0={H0_lcdm:.2f} Om={Om_lcdm:.4f} chi2={chi2_lcdm:.4f} chi2/N={chi2_lcdm/N:.4f}")

# ── MCMC (full 5-param) ──
def log_likelihood(theta):
    H0,Om,eps,omega,delta=theta
    return -0.5*np.sum(((H_obs-H_model(z_obs,H0,Om,eps,omega,delta))/sigma)**2)
def log_prior(theta):
    H0,Om,eps,omega,delta=theta
    if(60<H0<80 and 0.20<Om<0.45 and 0<=eps<=0.10 and 0.5<=omega<=6.0 and 0<=delta<=2*np.pi):
        return 0.0
    return -np.inf
def log_post(theta):
    lp=log_prior(theta)
    return lp+log_likelihood(theta) if np.isfinite(lp) else -np.inf

ndim,nwalkers,nsteps,burnin=5,64,5000,1500
p0=np.array([H0_lcdm,Om_lcdm,0.030,3.0,1.5])
p0s=p0+np.random.randn(nwalkers,ndim)*np.array([0.5,0.01,0.005,0.3,0.3])
p0s[:,2]=np.clip(p0s[:,2],0.001,0.099)
p0s[:,3]=np.clip(p0s[:,3],0.6,5.9)
p0s[:,4]=p0s[:,4]%(2*np.pi)

print("Running MCMC (5000 steps)...")
sampler=emcee.EnsembleSampler(nwalkers,ndim,log_post)
sampler.run_mcmc(p0s,nsteps,progress=False)
flat=sampler.get_chain(discard=burnin,thin=15,flat=True)
print(f"Flat samples: {flat.shape}")

# Acceptance fractions
acc=sampler.acceptance_fraction
print(f"Acceptance: mean={acc.mean():.3f} min={acc.min():.3f} max={acc.max():.3f}")

# Autocorrelation
try:
    tau=sampler.get_autocorr_time(quiet=True)
    print(f"Autocorr times: {tau}")
    tau_eps=tau[2]
except:
    tau_eps=40.0
    print("Autocorr estimate: ~40 steps")

# Posterior stats
lp_flat=sampler.get_log_prob(discard=burnin,thin=15,flat=True)
best_idx=np.argmax(lp_flat)
best_theta=flat[best_idx]
H0_map,Om_map,eps_map,omega_map,delta_map=best_theta
chi2_map=-2*log_likelihood(best_theta)

labels=['H0','Om','eps','omega','delta']
medians=np.median(flat,axis=0)
lo=np.percentile(flat,16,axis=0)
hi=np.percentile(flat,84,axis=0)
p95=np.percentile(flat,95,axis=0)

print(f"\nMAP: H0={H0_map:.2f} Om={Om_map:.4f} eps={eps_map:.4f} omega={omega_map:.3f} delta={delta_map:.3f}")
print(f"chi2_MAP={chi2_map:.4f}")
for i,l in enumerate(labels):
    print(f"  {l}: median={medians[i]:.4f} +{hi[i]-medians[i]:.4f} -{medians[i]-lo[i]:.4f} 95pct={p95[i]:.4f}")

# AIC/BIC (MAP)
k_lcdm=2; k_mod=5
AIC_lcdm=chi2_lcdm+2*k_lcdm; BIC_lcdm=chi2_lcdm+k_lcdm*np.log(N)
AIC_mod=chi2_map+2*k_mod;     BIC_mod=chi2_map+k_mod*np.log(N)
dAIC=AIC_mod-AIC_lcdm; dBIC=BIC_mod-BIC_lcdm
print(f"\nLCDM:  chi2={chi2_lcdm:.3f} AIC={AIC_lcdm:.3f} BIC={BIC_lcdm:.3f}")
print(f"Model: chi2={chi2_map:.3f}  AIC={AIC_mod:.3f}  BIC={BIC_mod:.3f}")
print(f"DAIC={dAIC:.3f}  DBIC={dBIC:.3f}  Dchi2={chi2_lcdm-chi2_map:.3f}")

# Profile chi2
print("\nComputing profile chi2...")
eps_grid=np.linspace(0,0.10,61)
chi2_prof=[]
for eps in eps_grid:
    def obj(x):
        H0,Om,omega,delta=x
        if not(60<H0<80 and 0.20<Om<0.45 and 0.5<omega<6.0): return 1e9
        return -log_likelihood([H0,Om,eps,omega,delta%(2*np.pi)])
    r=minimize(obj,[H0_lcdm,Om_lcdm,3.6,2.0],method='Nelder-Mead',
               options={'xatol':1e-5,'fatol':1e-5,'maxiter':3000})
    chi2_prof.append(2*r.fun)
chi2_prof=np.array(chi2_prof)
chi2_prof_min=chi2_prof.min()
delta_chi2_prof=chi2_prof-chi2_prof_min

# 95% UL from profile
try:
    f_prof=interp1d(eps_grid,delta_chi2_prof,kind='cubic')
    eps_95_prof=brentq(lambda e:f_prof(e)-3.84,0.04,0.10)
except:
    eps_95_prof=np.percentile(flat[:,2],95)
print(f"Profile 95% UL: eps < {eps_95_prof:.4f}")
print(f"MCMC  95% UL:   eps < {np.percentile(flat[:,2],95):.4f}")

# Save all
np.save('/home/claude/mcmc_flat_final.npy', flat)
np.save('/home/claude/final_stats.npy', np.array([
    chi2_lcdm, AIC_lcdm, BIC_lcdm, H0_lcdm, Om_lcdm,
    chi2_map,  AIC_mod,  BIC_mod,  H0_map, Om_map,
    eps_map, omega_map, delta_map,
    medians[0],medians[1],medians[2],medians[3],medians[4],
    lo[2],hi[2],lo[3],hi[3],
    np.percentile(flat[:,2],95), eps_95_prof,
    dAIC, dBIC, chi2_lcdm-chi2_map, float(N), tau_eps
]))
np.save('/home/claude/chi2_profile_final.npy', np.array([eps_grid, delta_chi2_prof]))
print("All saved.")
