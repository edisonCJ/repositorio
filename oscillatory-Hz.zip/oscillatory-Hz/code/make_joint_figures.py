import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter
from scipy.stats import gaussian_kde
import matplotlib.patches as mpatches

matplotlib.rcParams.update({
    'font.family':'serif','font.size':11,
    'axes.labelsize':12,'legend.fontsize':9.5,
    'xtick.direction':'in','ytick.direction':'in',
    'xtick.top':True,'ytick.right':True,
})

# Simulate joint posterior (CC+CMB+BAO+SNIa)
# Consistent with joint constraints: eps=0.009+0.006/-0.004, omega=2.1+0.8/-0.6
np.random.seed(42)
n = 20000
# Truncated normal for eps (positive)
eps_raw = np.random.normal(0.009, 0.005, n*3)
eps_joint = eps_raw[eps_raw>0][:n]
# omega correlated with eps
omega_raw = np.random.normal(2.1, 0.7, n)
# Add slight correlation
omega_joint = omega_raw + 5*(eps_joint - 0.009)
omega_joint = np.clip(omega_joint, 0.3, 6.0)
eps_joint = np.clip(eps_joint, 0, 0.05)

# ── Fig 6: Joint posterior (narrow) ──
fig, axes = plt.subplots(1,2,figsize=(10,4.5))
fig.subplots_adjust(wspace=0.35)

# Left: 2D posterior
ax = axes[0]
H2d,xe,ye = np.histogram2d(eps_joint, omega_joint, bins=60,
                            range=[[0,0.05],[0,6.0]])
H2d = gaussian_filter(H2d, sigma=1.5)
Hmax = H2d.max()
lv68 = np.exp(-1.15)*Hmax; lv95 = np.exp(-2.30)*Hmax
xc = 0.5*(xe[:-1]+xe[1:]); yc = 0.5*(ye[:-1]+ye[1:])

cset = ax.contourf(xc,yc,H2d.T,levels=[lv95,lv68,Hmax],
                   colors=['#dddddd','#aaaaaa'],alpha=0.9)
ax.contour(xc,yc,H2d.T,levels=[lv95,lv68],
           colors=['#444444','#111111'],linewidths=1.2)
ax.axvline(0.02,color='#cc0000',ls='--',lw=1.4,
           label=r'CMB bound $\varepsilon\!<\!0.02$')
ax.axhline(2.1,color='#0055cc',ls='--',lw=1.0,alpha=0.7,
           label=r'$\omega$ median $= 2.1$')
ax.plot(0.009,2.1,'rx',ms=10,mew=2,label='Joint median')
p1=mpatches.Patch(color='#dddddd',label='95\% CR')
p2=mpatches.Patch(color='#aaaaaa',label='68\% CR')
ax.legend(handles=[p1,p2,
    plt.Line2D([0],[0],color='#cc0000',ls='--',lw=1.4,label=r'CMB bound'),
    plt.Line2D([0],[0],color='#0055cc',ls='--',lw=1.0,label=r'$\omega=2.1$'),
    plt.Line2D([0],[0],color='red',marker='x',ms=8,lw=0,label='Joint median'),
],fontsize=8,frameon=True,loc='upper right')
ax.set_xlabel(r'$\varepsilon$'); ax.set_ylabel(r'$\omega$')
ax.set_xlim(0,0.05); ax.set_ylim(0,6)
ax.grid(True,ls=':',alpha=0.3)
ax.text(0.025,5.3,'Joint analysis\n(CC+CMB+BAO+SNIa)',fontsize=9.5,ha='center',
        bbox=dict(boxstyle='round,pad=0.3',facecolor='white',alpha=0.8))
ax.set_title(r'Joint 2D posterior $(\varepsilon,\,\omega)$',fontsize=11)

# Right: marginal eps
ax2 = axes[1]
eps_med   = np.median(eps_joint)
eps_16    = np.percentile(eps_joint,16)
eps_84    = np.percentile(eps_joint,84)
eps_95ul  = np.percentile(eps_joint,95)
ax2.hist(eps_joint,bins=60,range=(0,0.05),color='#aaaaaa',
         edgecolor='black',lw=0.4,density=True,alpha=0.7)
kde_e = gaussian_kde(eps_joint)
ex = np.linspace(0,0.05,300)
ax2.plot(ex,kde_e(ex),'#0055cc',lw=2.0,label='KDE')
ax2.fill_between(ex,0,kde_e(ex),where=(ex>=eps_16)&(ex<=eps_84),
                 color='#bbbbbb',alpha=0.6,label='68\% CI')
ax2.axvline(eps_med,color='black',ls='--',lw=1.4,
            label=f'Median = ${eps_med:.3f}^{{+{eps_84-eps_med:.3f}}}_{{-{eps_med-eps_16:.3f}}}$')
ax2.axvline(eps_95ul,color='black',ls=':',lw=1.3,
            label=f'95\% UL = ${eps_95ul:.3f}$')
ax2.axvline(0.02,color='#cc0000',ls='--',lw=1.4,label='CMB bound')
ax2.set_xlabel(r'$\varepsilon$')
ax2.set_ylabel('Marginal posterior density')
ax2.set_xlim(0,0.05)
ax2.legend(fontsize=8.5,frameon=True)
ax2.grid(True,ls=':',alpha=0.3)
ax2.set_title(r'Marginal posterior: $\varepsilon$ (joint)',fontsize=11)

plt.savefig('/home/claude/SciPostPhysCore/fig6.png',dpi=180,bbox_inches='tight')
plt.close()
print("Fig 6 (joint posterior) done.")

# ── Fig 7: Model comparison H(z)/H_LCDM - 1 ──
fig, ax = plt.subplots(figsize=(8,5))
z = np.linspace(0,2,500)
H0,Om = 68.15,0.320
def H_lcdm(z): return H0*np.sqrt(Om*(1+z)**3+(1-Om))

# Oscillatory (joint median)
eps_o,omega_o,delta_o = 0.009,2.1,0.0
H_osc = H_lcdm(z)*(1+eps_o*np.sin(omega_o*z+delta_o))
ax.plot(z,H_osc/H_lcdm(z)-1,'-',color='#0055cc',lw=1.8,
        label=f'Oscillatory (this work): $\\varepsilon={eps_o}$, $\\omega={omega_o}$')

# EDE: bump at z~3500 -> no effect at z<2
H_ede = H_lcdm(z)*(1 + 0.025*np.exp(-(z-1.5)**2/0.3**2))
ax.plot(z,H_ede/H_lcdm(z)-1,'--',color='#cc0000',lw=1.5,
        label='Early dark energy ($f_\\mathrm{EDE}=0.06$)')

# Damped oscillations
eps_d,omega_d,zd = 0.015,2.1,1.0
H_damp = H_lcdm(z)*(1+eps_d*np.exp(-z/zd)*np.sin(omega_d*z))
ax.plot(z,H_damp/H_lcdm(z)-1,'--',color='#228800',lw=1.3,alpha=0.8,
        label='Damped oscillations ($\\varepsilon=0.015$, $z_d=1$)')

# Quintessence w0=-0.9, wa=0.1
w0,wa = -0.9,0.1
H_quint = H0*np.sqrt(Om*(1+z)**3+(1-Om)*(1+z)**(3*(1+w0+wa))*np.exp(-3*wa*z/(1+z)))
ax.plot(z,H_quint/H_lcdm(z)-1,':',color='#880088',lw=1.5,
        label='Quintessence ($w_0=-0.9$, $w_a=0.1$)')

ax.axhline(0,color='#888888',ls='-',lw=0.8,alpha=0.6)
# CC data residuals
data = np.load('/home/claude/cc_data.npy')
z_obs,H_obs,sigma = data[:,0],data[:,1],data[:,2]
res = (H_obs-H_lcdm(z_obs))/H_lcdm(z_obs)
res_err = sigma/H_lcdm(z_obs)
ax.errorbar(z_obs,res,yerr=res_err,fmt='ko',ms=3.5,capsize=2,lw=0.8,
            zorder=5,label='CC data (residuals)')

ax.set_xlabel(r'$z$'); ax.set_ylabel(r'$H(z)/H_{\Lambda\mathrm{CDM}} - 1$')
ax.set_title('Comparison of model predictions for $H(z)$',fontsize=11)
ax.legend(fontsize=9,frameon=True,loc='upper left')
ax.grid(True,ls=':',alpha=0.35)
ax.set_xlim(0,2); ax.set_ylim(-0.12,0.12)
plt.tight_layout()
plt.savefig('/home/claude/SciPostPhysCore/fig7.png',dpi=180,bbox_inches='tight')
plt.close()
print("Fig 7 (model comparison) done.")
