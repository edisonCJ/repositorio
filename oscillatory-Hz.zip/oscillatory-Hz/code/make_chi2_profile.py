import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import minimize_scalar, minimize

matplotlib.rcParams.update({
    'font.family': 'serif', 'font.size': 11,
    'axes.labelsize': 12, 'legend.fontsize': 10,
    'xtick.direction': 'in', 'ytick.direction': 'in',
    'xtick.top': True, 'ytick.right': True,
})

data = np.load('/home/claude/cc_data.npy')
z_obs, H_obs, sigma = data[:,0], data[:,1], data[:,2]

def H_LCDM(z, H0, Om): return H0*np.sqrt(Om*(1+z)**3+(1-Om))
def H_mod(z, H0, Om, eps, omega, delta):
    return H_LCDM(z,H0,Om)*(1+eps*np.sin(omega*z+delta))
def chi2_full(theta):
    H0,Om,eps,omega,delta = theta
    return np.sum(((H_obs-H_mod(z_obs,H0,Om,eps,omega,delta))/sigma)**2)

# Profile chi2 as function of eps (minimize over other params)
eps_grid = np.linspace(0.0, 0.10, 51)
chi2_profile = []
print("Computing chi2 profile...")
for eps in eps_grid:
    def objective(x):
        H0,Om,omega,delta = x
        if not (60<H0<80 and 0.20<Om<0.45 and 0.5<omega<6.0):
            return 1e9
        return chi2_full([H0,Om,eps,omega,delta % (2*np.pi)])
    r = minimize(objective, [68.2, 0.32, 3.6, 2.0],
                 method='Nelder-Mead',
                 options={'xatol':1e-4,'fatol':1e-4,'maxiter':2000})
    chi2_profile.append(r.fun)
    if int(eps*100) % 10 == 0:
        print(f"  eps={eps:.3f} chi2={r.fun:.3f}")

chi2_profile = np.array(chi2_profile)
chi2_min = chi2_profile.min()

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.plot(eps_grid, chi2_profile - chi2_min, 'k-', lw=1.8,
        label=r'Profile $\Delta\chi^2(\varepsilon)$')
ax.axhline(1.0, color='#888888', ls='--', lw=1.2, label=r'$\Delta\chi^2=1$ (68% CL)')
ax.axhline(3.84, color='#888888', ls=':', lw=1.2, label=r'$\Delta\chi^2=3.84$ (95% CL)')
ax.axvline(0.02, color='#cc0000', ls='-.', lw=1.3, label='CMB/BAO bound eps=0.02')

# Find 95% upper limit
from scipy.interpolate import interp1d
f_interp = interp1d(eps_grid, chi2_profile - chi2_min, kind='cubic')
# Find where it crosses 3.84
from scipy.optimize import brentq
try:
    eps_95_prof = brentq(lambda e: f_interp(e)-3.84, 0.05, 0.10)
    ax.axvline(eps_95_prof, color='black', ls=':', lw=1.3,
               label=f'Profile 95% UL: eps={eps_95_prof:.3f}')
except:
    pass

ax.set_xlabel(r'$\varepsilon$')
ax.set_ylabel(r'$\Delta\chi^2 = \chi^2(\varepsilon) - \chi^2_{\min}$')
ax.set_title(r'Profile likelihood: $\Delta\chi^2$ as a function of $\varepsilon$', fontsize=11)
ax.legend(frameon=True, fontsize=9.5)
ax.grid(True, ls=':', alpha=0.35)
ax.set_xlim(0, 0.10)
ax.set_ylim(-0.2, 6.0)
plt.tight_layout()
plt.savefig('/home/claude/fig5_chi2profile.png', dpi=180, bbox_inches='tight')
plt.close()
print("Fig 5 saved.")
