import numpy as np
import emcee
from scipy.optimize import minimize

np.random.seed(2024)
H0_true, Om_true = 70.0, 0.30

def H_LCDM(z,H0,Om): return H0*np.sqrt(Om*(1+z)**3+(1-Om))
def H_model(z,H0,Om,eps,omega,delta): return H_LCDM(z,H0,Om)*(1+eps*np.sin(omega*z+delta))

def run_recovery(eps_inj, omega_inj=3.0, delta_inj=0.0, n_pts=25, noise=0.07,
                 nwalkers=32, nsteps=2000, burnin=600, label=''):
    z = np.linspace(0.1,2.0,n_pts)
    H_true = H_model(z,H0_true,Om_true,eps_inj,omega_inj,delta_inj)
    sig    = noise*H_true
    H_obs  = H_true + np.random.normal(0,sig)

    def neg_lcdm(p):
        H0,Om=p
        if not(60<H0<80 and 0.2<Om<0.45): return 1e9
        return 0.5*np.sum(((H_obs-H_LCDM(z,H0,Om))/sig)**2)
    r0=minimize(neg_lcdm,[70,0.30],method='Nelder-Mead')
    chi2_lcdm=r0.fun*2  # it's 0.5*chi2

    def lp(theta):
        H0,Om,eps,omega,delta=theta
        if not(60<H0<80 and 0.2<Om<0.45 and 0<=eps<=0.10 and 0.5<=omega<=6.0 and 0<=delta<=2*np.pi):
            return -np.inf
        return -0.5*np.sum(((H_obs-H_model(z,H0,Om,eps,omega,delta))/sig)**2)

    ndim=5
    p0=np.array([70,0.30,max(eps_inj,0.01),3.0,1.0])
    p0s=p0+np.random.randn(nwalkers,ndim)*np.array([0.5,0.01,0.005,0.3,0.3])
    p0s[:,2]=np.clip(p0s[:,2],0.001,0.099)
    p0s[:,3]=np.clip(p0s[:,3],0.6,5.9)
    p0s[:,4]=p0s[:,4]%(2*np.pi)

    sampler=emcee.EnsembleSampler(nwalkers,ndim,lp)
    sampler.run_mcmc(p0s,nsteps,progress=False)
    flat=sampler.get_chain(discard=burnin,thin=5,flat=True)

    eps_med = np.median(flat[:,2])
    eps_lo  = np.percentile(flat[:,2],16)
    eps_hi  = np.percentile(flat[:,2],84)
    eps_sig = (eps_hi-eps_lo)/2

    lp_vals = np.array([-0.5*np.sum(((H_obs-H_model(z,*s))/sig)**2) for s in flat])
    chi2_mod = -2*np.max(lp_vals)
    dchi2    = chi2_lcdm - chi2_mod

    bias = eps_med - eps_inj
    # Coverage: is true value within 68% CI?
    covered = (eps_lo <= eps_inj <= eps_hi)

    if eps_inj==0:
        status='No false positive' if eps_med<0.020 else 'Noise floor detected'
    elif abs(bias) < eps_sig:
        status='Consistent recovery'
    elif abs(bias) < 2*eps_sig:
        status='Marginal recovery'
    else:
        status='Poor recovery'

    return dict(label=label, eps_inj=eps_inj, eps_med=eps_med,
                eps_lo=eps_lo, eps_hi=eps_hi, eps_sig=eps_sig,
                bias=bias, covered=covered, dchi2=dchi2, status=status)

# Run 6 cases (more than before, plus null test)
cases=[
    (0.000,  3.0,  0.0, 'Null test'),
    (0.010,  3.0,  0.0, 'eps=0.010'),
    (0.015,  3.0,  0.0, 'eps=0.015'),
    (0.020,  3.0,  0.0, 'eps=0.020'),
    (0.030,  3.0,  0.0, 'eps=0.030'),
    (0.050,  3.0,  0.0, 'eps=0.050'),
]

results=[]
print(f"{'Label':<15} {'eps_inj':>8} {'eps_rec':>8} {'sigma':>7} {'bias':>8} {'cover':>6} {'dchi2':>7} Status")
print("-"*80)
for eps_inj,omega_inj,delta_inj,label in cases:
    r=run_recovery(eps_inj,omega_inj,delta_inj,label=label)
    results.append(r)
    print(f"{label:<15} {r['eps_inj']:>8.3f} {r['eps_med']:>8.4f} {r['eps_sig']:>7.4f} "
          f"{r['bias']:>8.4f} {str(r['covered']):>6} {r['dchi2']:>7.2f}  {r['status']}")

# Noise floor estimate
null_eps = results[0]['eps_med']
print(f"\nNoise floor: eps_floor ~ {null_eps:.3f}")
np.save('/home/claude/synthetic_final.npy', 
        np.array([(r['eps_inj'],r['eps_med'],r['eps_lo'],r['eps_hi'],
                   r['bias'],r['dchi2'],float(r['covered'])) for r in results]))
print("Saved.")
