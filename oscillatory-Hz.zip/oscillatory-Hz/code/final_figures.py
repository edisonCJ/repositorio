import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from scipy.ndimage import gaussian_filter
from scipy.integrate import quad
from scipy.fft import rfft, rfftfreq
import matplotlib.patches as mpatches

matplotlib.rcParams.update({
    'font.family':'serif','font.size':11,
    'axes.labelsize':12,'legend.fontsize':10,
    'xtick.direction':'in','ytick.direction':'in',
    'xtick.top':True,'ytick.right':True,
})

# ── Load data ──
data  = np.load('/home/claude/cc_data.npy')
flat  = np.load('/home/claude/mcmc_flat_final.npy')
stats = np.load('/home/claude/final_stats.npy')
chi2p = np.load('/home/claude/chi2_profile_final.npy')
synth = np.load('/home/claude/synthetic_final.npy')

z_obs,H_obs,sigma = data[:,0],data[:,1],data[:,2]
H0_lcdm,Om_lcdm   = stats[3], stats[4]
eps_med,omega_med,delta_med = stats[15],stats[16],stats[17]
eps_lo,eps_hi      = stats[18],stats[19]
omega_lo,omega_hi  = stats[20],stats[21]
eps_95             = stats[22]
dAIC,dBIC          = stats[24],stats[25]

def H_LCDM(z,H0=H0_lcdm,Om=Om_lcdm): return H0*np.sqrt(Om*(1+z)**3+(1-Om))
def H_mod(z,H0=None,Om=None,eps=None,omega=None,delta=None):
    H0=H0 or stats[13]; Om=Om or stats[14]
    eps=eps if eps is not None else eps_med
    omega=omega if omega is not None else omega_med
    delta=delta if delta is not None else delta_med
    return H_LCDM(z,H0,Om)*(1+eps*np.sin(omega*z+delta))

z_fine = np.linspace(0,2.1,500)

# ════════════════════════════
# FIG 1: H(z) + residuals
# ════════════════════════════
fig,(ax1,ax2)=plt.subplots(2,1,figsize=(7,8),
    gridspec_kw={'height_ratios':[2.2,1],'hspace':0.06})

idx=np.random.choice(len(flat),400,replace=False)
band=np.array([H_LCDM(z_fine,flat[i,0],flat[i,1])*
               (1+flat[i,2]*np.sin(flat[i,3]*z_fine+flat[i,4])) for i in idx])

ax1.fill_between(z_fine,np.percentile(band,16,axis=0),
                          np.percentile(band,84,axis=0),
                 color='#cccccc',alpha=0.8,label=r'$1\sigma$ posterior band')
ax1.errorbar(z_obs,H_obs,yerr=sigma,fmt='o',color='black',
             ms=4.5,capsize=3,lw=0.9,zorder=5,label='Cosmic chronometers')
ax1.plot(z_fine,H_LCDM(z_fine),'--',color='#555555',lw=1.6,
         label=r'$\Lambda$CDM ($H_0=68.2$, $\Omega_m=0.320$)')
ax1.plot(z_fine,H_mod(z_fine),'-',color='black',lw=1.6,
         label=rf'Oscillatory ($\varepsilon={eps_med:.3f}$, $\omega={omega_med:.2f}$)')
ax1.set_ylabel(r'$H(z)$ [km s$^{-1}$ Mpc$^{-1}$]')
ax1.set_xlim(0,2.1); ax1.set_ylim(40,260)
ax1.legend(loc='upper left',frameon=True,framealpha=0.92,fontsize=9.5)
ax1.grid(True,ls=':',alpha=0.35)
ax1.tick_params(labelbottom=False)

res_obs =(H_obs-H_LCDM(z_obs))/H_LCDM(z_obs)
res_err = sigma/H_LCDM(z_obs)
res_fine=(H_mod(z_fine)-H_LCDM(z_fine))/H_LCDM(z_fine)
band_res=(band-H_LCDM(z_fine))/H_LCDM(z_fine)

ax2.axhline(0,color='#555555',ls='--',lw=1.0)
ax2.fill_between(z_fine,np.percentile(band_res,16,axis=0),
                          np.percentile(band_res,84,axis=0),
                 color='#cccccc',alpha=0.8)
ax2.errorbar(z_obs,res_obs,yerr=res_err,fmt='o',color='black',
             ms=4.5,capsize=3,lw=0.9,zorder=5)
ax2.plot(z_fine,res_fine,'-',color='black',lw=1.6)
ax2.set_xlabel(r'$z$')
ax2.set_ylabel(r'$(H_\mathrm{obs}-H_{\Lambda\mathrm{CDM}})/H_{\Lambda\mathrm{CDM}}$')
ax2.set_xlim(0,2.1); ax2.set_ylim(-0.45,0.45)
ax2.grid(True,ls=':',alpha=0.35)
ax2.text(0.02,0.05,
    'Error bars: $1\\sigma$. Oscillatory pattern within observational uncertainties.\n'
    'Signal identification requires Fourier-based statistical methods.',
    transform=ax2.transAxes,fontsize=8.5,color='#333333',va='bottom')
plt.savefig('/home/claude/SciPostPhysCore/fig1.png',dpi=180,bbox_inches='tight')
plt.close(); print("Fig 1 done.")

# ════════════════════════════
# FIG 2: 2D posterior + marginal
# ════════════════════════════
fig,axes=plt.subplots(1,2,figsize=(10,4.5))
fig.subplots_adjust(wspace=0.35)

eps_s=flat[:,2]; omega_s=flat[:,3]
H2d,xe,ye=np.histogram2d(eps_s,omega_s,bins=60,range=[[0,0.10],[0.5,6.0]])
H2d=gaussian_filter(H2d,sigma=1.5); Hmax=H2d.max()
lv68=np.exp(-1.15)*Hmax; lv95=np.exp(-2.30)*Hmax
xc=0.5*(xe[:-1]+xe[1:]); yc=0.5*(ye[:-1]+ye[1:])

ax=axes[0]
ax.contourf(xc,yc,H2d.T,levels=[lv95,lv68,Hmax],colors=['#dddddd','#aaaaaa'],alpha=0.9)
ax.contour(xc,yc,H2d.T,levels=[lv95,lv68],colors=['#444444','#111111'],linewidths=1.2)
ax.axvline(eps_med,color='black',ls='--',lw=1.3)
ax.axvline(eps_95, color='black',ls=':' ,lw=1.3)
ax.axvline(0.02,   color='#cc0000',ls='-.',lw=1.3)
p1=mpatches.Patch(color='#dddddd',label='95% CR')
p2=mpatches.Patch(color='#aaaaaa',label='68% CR')
ax.legend(handles=[p1,p2,
    plt.Line2D([0],[0],color='black',ls='--',lw=1.3,label=f'Median $\\varepsilon={eps_med:.3f}$'),
    plt.Line2D([0],[0],color='black',ls=':',lw=1.3,label=f'95% UL $\\varepsilon<{eps_95:.3f}$'),
    plt.Line2D([0],[0],color='#cc0000',ls='-.',lw=1.3,label='CMB/BAO $\\varepsilon<0.02$'),
],fontsize=8,frameon=True,loc='upper right')
ax.set_xlabel(r'$\varepsilon$'); ax.set_ylabel(r'$\omega$')
ax.set_xlim(0,0.10); ax.set_ylim(0.5,6.0)
ax.grid(True,ls=':',alpha=0.3)
ax.set_title(r'2D posterior $(\varepsilon,\,\omega)$',fontsize=11)

ax2=axes[1]
ax2.hist(eps_s,bins=50,range=(0,0.10),color='#aaaaaa',edgecolor='black',lw=0.4,density=True)
ax2.axvline(eps_med,color='black',ls='--',lw=1.4,
    label=f'Median = ${eps_med:.3f}^{{+{eps_hi-eps_med:.3f}}}_{{-{eps_med-eps_lo:.3f}}}$')
ax2.axvline(eps_95,color='black',ls=':',lw=1.4,label=f'95% UL = ${eps_95:.3f}$')
ax2.axvline(0.02,color='#cc0000',ls='-.',lw=1.4,label='CMB/BAO bound')
ax2.set_xlabel(r'$\varepsilon$'); ax2.set_ylabel('Marginal posterior density')
ax2.set_xlim(0,0.10); ax2.legend(fontsize=8.5,frameon=True)
ax2.grid(True,ls=':',alpha=0.3)
ax2.set_title(r'Marginal posterior: $\varepsilon$',fontsize=11)
plt.savefig('/home/claude/SciPostPhysCore/fig2.png',dpi=180,bbox_inches='tight')
plt.close(); print("Fig 2 done.")

# ════════════════════════════
# FIG 3: Δμ(z) + Fourier
# ════════════════════════════
fig,(ax1,ax2)=plt.subplots(1,2,figsize=(10,4.5))
fig.subplots_adjust(wspace=0.38)

def dL(z,H0,Om,eps,omega,delta):
    def intgd(zp): return 1.0/(H0*np.sqrt(Om*(1+zp)**3+(1-Om))*(1+eps*np.sin(omega*zp+delta)))
    r,_=quad(intgd,0,z); return (1+z)*2.998e5*r
def dL_lcdm(z,H0=H0_lcdm,Om=Om_lcdm):
    def intgd(zp): return 1.0/(H0*np.sqrt(Om*(1+zp)**3+(1-Om)))
    r,_=quad(intgd,0,z); return (1+z)*2.998e5*r

z_sn=np.linspace(0.02,2.0,60)
H0m=stats[13]; Omm=stats[14]
dmu=np.array([5*np.log10(dL(z,H0m,Omm,eps_med,omega_med,delta_med)/dL_lcdm(z)) for z in z_sn])
# Also CMB-consistent prediction (eps=0.015)
dmu_cmb=np.array([5*np.log10(dL(z,H0m,Omm,0.015,omega_med,delta_med)/dL_lcdm(z)) for z in z_sn])

ax1.plot(z_sn,dmu,'k-',lw=1.6,label=rf'$\varepsilon={eps_med:.3f}$ (median posterior)')
ax1.plot(z_sn,dmu_cmb,'k--',lw=1.2,label=r'$\varepsilon=0.015$ (CMB-consistent)')
ax1.axhline(0,color='gray',ls='--',lw=0.8)
ax1.fill_between(z_sn,-0.05,0.05,color='#cccccc',alpha=0.5,label='Rubin/LSST floor ($\\sim$0.05 mag)')
ax1.set_xlabel(r'$z$'); ax1.set_ylabel(r'$\Delta\mu(z)$ [mag]')
ax1.set_title('Predicted SN Ia distance residuals',fontsize=11)
ax1.legend(fontsize=9,frameon=True); ax1.grid(True,ls=':',alpha=0.35)
ax1.set_xlim(0,2); ax1.set_ylim(-0.18,0.18)

z_u=np.linspace(0.05,2.0,200)
dH=(H_mod(z_u)-H_LCDM(z_u))/H_LCDM(z_u)
dz=z_u[1]-z_u[0]
freqs=rfftfreq(len(dH),d=dz)
power=np.abs(rfft(dH))**2
pk=np.argmax(power[2:])+2
ax2.plot(freqs,power/power.max(),'k-',lw=1.2,label='Normalized power')
ax2.axvline(freqs[pk],color='black',ls='--',lw=1.4,
            label=f'Expected peak: $\\nu={freqs[pk]:.2f}$')
ax2.axvline(omega_med/(2*np.pi),color='#cc0000',ls=':',lw=1.4,
            label=f'$\\omega/2\\pi={omega_med/(2*np.pi):.2f}$')
ax2.axvline(4.0,color='#888888',ls='-.',lw=1.0,label='Nyquist (8 pts/unit-$z$)')
ax2.set_xlabel(r'Frequency $[(\Delta z)^{-1}]$')
ax2.set_ylabel('Normalized power spectrum')
ax2.set_title(r'Fourier spectrum of $\Delta H/H_{\Lambda\mathrm{CDM}}$',fontsize=11)
ax2.set_xlim(0,4); ax2.set_ylim(0,1.05)
ax2.legend(fontsize=9,frameon=True); ax2.grid(True,ls=':',alpha=0.35)
plt.savefig('/home/claude/SciPostPhysCore/fig3.png',dpi=180,bbox_inches='tight')
plt.close(); print("Fig 3 done.")

# ════════════════════════════
# FIG 4: Injection-recovery (6 cases)
# ════════════════════════════
fig,ax=plt.subplots(figsize=(8,4.5))
labels=['Null','eps=0.010','eps=0.015','eps=0.020','eps=0.030','eps=0.050']
eps_inj=synth[:,0]; eps_rec=synth[:,1]; eps_lo_s=synth[:,2]; eps_hi_s=synth[:,3]
x=np.arange(len(labels))
ax.errorbar(x,eps_rec,yerr=[eps_rec-eps_lo_s,eps_hi_s-eps_rec],
            fmt='o',color='black',ms=7,capsize=5,lw=1.5,zorder=5,
            label='Recovered median (68% CR)')
ax.plot(x,eps_inj,'s--',color='#cc0000',ms=7,lw=1.5,label='Injected value')
ax.axhline(0.02,color='#888888',ls=':',lw=1.3,label='CMB/BAO bound')
ax.fill_between([-0.5,5.5],0,0.028,color='#eeeeee',alpha=0.7,label='Noise floor region')
ax.set_xticks(x); ax.set_xticklabels(labels,fontsize=10)
ax.set_ylabel(r'$\varepsilon$')
ax.set_title('Injection–recovery test: 6 cases with 25 synthetic CC measurements',fontsize=11)
ax.legend(frameon=True,fontsize=9.5,loc='upper left')
ax.grid(True,ls=':',alpha=0.35)
ax.set_xlim(-0.5,5.5); ax.set_ylim(-0.01,0.115)
ax.annotate('Noise\nfloor',xy=(0,0.028),xytext=(0.4,0.005),fontsize=8.5,
            color='#666666',va='bottom')
plt.tight_layout()
plt.savefig('/home/claude/SciPostPhysCore/fig4.png',dpi=180,bbox_inches='tight')
plt.close(); print("Fig 4 done.")

# ════════════════════════════
# FIG 5: Profile chi2
# ════════════════════════════
eps_grid,dchi2=chi2p[0],chi2p[1]
fig,ax=plt.subplots(figsize=(7,4.5))
ax.plot(eps_grid,dchi2,'k-',lw=1.8,label=r'Profile $\Delta\chi^2(\varepsilon)$')
ax.axhline(1.0,color='#888888',ls='--',lw=1.2,label=r'$\Delta\chi^2=1$ (68% CL)')
ax.axhline(3.84,color='#888888',ls=':',lw=1.2,label=r'$\Delta\chi^2=3.84$ (95% CL)')
ax.axvline(0.02,color='#cc0000',ls='-.',lw=1.3,label='CMB/BAO bound')
ax.axvline(0.028,color='#888888',ls='-.',lw=1.0,label='Noise floor ($\\sim$0.028)')
# shade the undetectable region
ax.fill_betweenx([0,6],0,0.028,color='#eeeeee',alpha=0.6)
ax.text(0.005,4.5,'Undetectable\n(below noise floor)',fontsize=8.5,color='#888888')
ax.set_xlabel(r'$\varepsilon$'); ax.set_ylabel(r'$\Delta\chi^2(\varepsilon)$')
ax.set_title(r'Profile likelihood: marginalized over $(H_0,\Omega_m,\omega,\delta)$',fontsize=11)
ax.legend(frameon=True,fontsize=9.5); ax.grid(True,ls=':',alpha=0.35)
ax.set_xlim(0,0.10); ax.set_ylim(0,6)
plt.tight_layout()
plt.savefig('/home/claude/SciPostPhysCore/fig5.png',dpi=180,bbox_inches='tight')
plt.close(); print("Fig 5 done.")
print("All figures complete.")
